"use client"
import Icon from "../formComponents/Icon";

export const BotonEditarProducto = ({item, ...props}) => (
  <Icon icono={"editar"} onClick={() => {}} {...props}/>
)