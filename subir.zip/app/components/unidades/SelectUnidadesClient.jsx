"use client"
import FilterSelect from "../formComponents/FilterSelect";

const SelectCategoriaClient =  (props) => <FilterSelect {...props}/>

export default SelectCategoriaClient;
