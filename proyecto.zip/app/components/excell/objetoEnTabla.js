export default function ObjetoEnExcel(objeto, origen) {













  return 0
}


function textoSeparadoPorComasExcel(){


}