import IaPrompt from "@/app/components/ia/IaPromp";

export default function PaginIA() {
  return (
    <main className='flex flex-col gap-5 container w-full max-w-full'>
      <IaPrompt></IaPrompt>
    </main>
  )
}
