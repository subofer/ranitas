"use client"
import Icon from "../formComponents/Icon";

export const BotonEliminarProducto = ({item, ...props}) => (
  <Icon icono={"eliminar"} {...props}/>
)